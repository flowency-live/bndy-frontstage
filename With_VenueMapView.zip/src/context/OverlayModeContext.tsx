"use client";

import { createContext, useContext, useState, ReactNode } from "react";

export type OverlayMode = "events" | "venues";

interface OverlayModeContextProps {
  overlayMode: OverlayMode;
  setOverlayMode: (mode: OverlayMode) => void;
  showAllVenues: boolean;
  setShowAllVenues: (show: boolean) => void;
}

const OverlayModeContext = createContext<OverlayModeContextProps | undefined>(undefined);

export function OverlayModeProvider({ children }: { children: ReactNode }) {
  const [overlayMode, setOverlayMode] = useState<OverlayMode>("events");
  // NEW: track whether we’re showing all venues or only those with future events
  const [showAllVenues, setShowAllVenues] = useState(false);

  return (
    <OverlayModeContext.Provider
      value={{ overlayMode, setOverlayMode, showAllVenues, setShowAllVenues }}
    >
      {children}
    </OverlayModeContext.Provider>
  );
}

export function useOverlayMode() {
  const context = useContext(OverlayModeContext);
  if (!context) {
    throw new Error("useOverlayMode must be used within an OverlayModeProvider");
  }
  return context;
}

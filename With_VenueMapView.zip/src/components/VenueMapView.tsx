"use client";

import React, { useEffect, useRef, useState } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "@/lib/config/firebase";
import { COLLECTIONS } from "@/lib/constants";
import { Venue } from "@/lib/types";
import VenueInfoOverlay from "@/components/overlays/VenueInfoOverlay";
import { useEvents } from "@/context/EventsContext";
import { useOverlayMode } from "@/context/OverlayModeContext"; // NEW
import { mapStyles } from "./map/MapStyles";
import { DEFAULT_CENTER } from "./map/sampleData";

interface VenueMapViewProps {
  filterType?: "artist" | "venue" | "nomatch" | null;
  filterId?: string | null;
  initialCenter?: google.maps.LatLngLiteral;
  initialZoom?: number;
  onMapLoaded?: (map: google.maps.Map) => void;
}

export default function VenueMapView({ 
  filterType, 
  filterId, 
  initialCenter, 
  initialZoom,
  onMapLoaded
}: VenueMapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [mapInstance, setMapInstance] = useState<google.maps.Map | null>(null);
  const [venueMarkers, setVenueMarkers] = useState<google.maps.Marker[]>([]);
  const [selectedVenue, setSelectedVenue] = useState<Venue | null>(null);

  // We remove local state for showOnlyFutureEvents
  // and rely on overlayMode context
  const { showAllVenues } = useOverlayMode();

  const { allEvents, loading: eventsLoading, userLocation } = useEvents();
  
  // Initialize map
  useEffect(() => {
    if (!mapRef.current) return;
    
    try {
      const map = new google.maps.Map(mapRef.current, {
        center: initialCenter || userLocation || DEFAULT_CENTER,
        zoom: initialZoom || 12,
        gestureHandling: "greedy",
        clickableIcons: false,
        zoomControl: true,
        mapTypeControl: false,
        streetViewControl: false,
        maxZoom: 18,
        minZoom: 3,
        styles: mapStyles
      });
      
      setMapInstance(map);
      onMapLoaded?.(map);
    } catch (error) {
      console.error("Error initializing venue map:", error);
    }
  }, [initialCenter, initialZoom, userLocation, onMapLoaded]);
  
  // Load venues when map changes or user toggles "All Venues"
  useEffect(() => {
    if (!mapInstance) return;
    
    // Clear previous markers
    venueMarkers.forEach(marker => marker.setMap(null));
    setVenueMarkers([]);
    
    async function loadVenues() {
      try {
        const snapshot = await getDocs(collection(db, COLLECTIONS.VENUES));
        let venues = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Venue[];

        // Filter by map bounds
        const bounds = mapInstance?.getBounds();
        if (bounds) {
          venues = venues.filter(venue => {
            if (!venue.location) return false;
            return bounds.contains({ lat: venue.location.lat, lng: venue.location.lng });
          });
        }
        
        // If user typed a venue name, filter by name
        if (filterType === "venue" && filterId?.trim()) {
          venues = venues.filter(venue => 
            venue.name.toLowerCase().includes(filterId.toLowerCase())
          );
        }
        
        // Build sets of venue IDs that have future events, etc.
        const now = new Date();
        const venueIdsWithFutureEvents = new Set<string>();
        allEvents.forEach(event => {
          const eventDate = new Date(event.date);
          if (eventDate >= now) {
            venueIdsWithFutureEvents.add(event.venueId);
          }
        });

        // If showAllVenues is false, show only venues that have future events
        if (!showAllVenues) {
          venues = venues.filter(venue => venueIdsWithFutureEvents.has(venue.id));
        }
        
        // Create markers
        const markers: google.maps.Marker[] = [];
        venues.forEach(venue => {
          if (!venue.location) return;
          
          const marker = new google.maps.Marker({
            position: { lat: venue.location.lat, lng: venue.location.lng },
            map: mapInstance,
            title: venue.name,
            icon: {
              path: google.maps.SymbolPath.CIRCLE,
              scale: 7,
              fillColor: "#06B6D4",
              fillOpacity: 1,
              strokeWeight: 1,
              strokeColor: "#0891b2"
            },
            optimized: false
          });
          
          marker.addListener("click", () => {
            mapInstance?.panTo({ lat: venue.location.lat, lng: venue.location.lng });
            setSelectedVenue(venue);
          });
          markers.push(marker);
        });
        
        setVenueMarkers(markers);
      } catch (error) {
        console.error("Error loading venues:", error);
      }
    }
    
    // Load venues initially + whenever the map finishes moving
    loadVenues();
    const boundsListener = mapInstance.addListener("idle", loadVenues);
    
    return () => {
      google.maps.event.removeListener(boundsListener);
      markersCleanup(venueMarkers);
    };
  }, [mapInstance, filterType, filterId, allEvents, showAllVenues]);
  
  // Cleanup function for markers
  function markersCleanup(markers: google.maps.Marker[]) {
    markers.forEach(marker => marker.setMap(null));
  }

  // Calculate upcoming events count
  const upcomingEventsCount = selectedVenue 
    ? allEvents.filter(event => {
        const eventDate = new Date(event.date);
        return event.venueId === selectedVenue.id && eventDate >= new Date();
      }).length
    : 0;

  return (
    <>
      <div ref={mapRef} style={{ width: "100%", height: "100%" }} />
      {eventsLoading && (
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black bg-opacity-70 text-white p-4 rounded">
          Loading venues...
        </div>
      )}
      {selectedVenue && (
        <VenueInfoOverlay
          venue={selectedVenue}
          isOpen={true}
          onClose={() => setSelectedVenue(null)}
          upcomingCount={upcomingEventsCount}
        />
      )}
    </>
  );
}

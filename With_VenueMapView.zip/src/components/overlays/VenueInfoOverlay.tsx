// src/components/overlays/VenueInfoOverlay.tsx
"use client";

import React, { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Building2 } from "lucide-react";
import Link from "next/link";
import { getDirectionsUrl } from "@/lib/utils/mapLinks";
import { Venue } from "@/lib/types"; // Use your Venue type

interface VenueInfoOverlayProps {
  venue: Venue; 
  isOpen: boolean;
  onClose: () => void;
  upcomingCount: number;
}

export default function VenueInfoOverlay({
  venue,
  isOpen,
  onClose,
  upcomingCount
}: VenueInfoOverlayProps) {
  const directionsUrl = venue ? getDirectionsUrl(venue) : "";

  useEffect(() => {
    // Any additional logic if needed.
  }, [venue]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div
          className="fixed top-0 left-0 w-full h-full z-50 flex items-center justify-center backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            onClick={(e) => e.stopPropagation()}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="relative w-[320px] bg-[var(--background)] rounded-lg shadow-lg border border-[var(--border)]"
            style={{ boxShadow: "0 4px 10px rgba(0,0,0,0.15)" }}
          >
            {/* Left highlight strip */}
            <div className="absolute top-0 left-0 h-full w-1 bg-[var(--secondary)] rounded-tl-lg rounded-bl-lg" />
            <div className="p-4 pl-6">
              <h3 className="font-semibold text-lg mb-2">{venue.name}</h3>
              <p className="mb-1">{venue.address || "No address provided"}</p>
              <p className="mb-3">
                {upcomingCount > 0
                  ? `${upcomingCount} upcoming event ${upcomingCount !== 1 ? "s " : "(in bndy)"}`
                  : "No events currently listed in bndy"}
              </p>
              <button
                onClick={() => {
                  onClose();
                  window.location.href = `/venues/${venue.id}`;
                }}
                className="px-4 py-2 rounded-md bg-cyan-500 text-white hover:bg-cyan-600 flex items-center gap-1"
              >
                <Building2 className="w-5 h-5" />
                <span>Go to Venue Page</span>
              </button>
              {directionsUrl && (
                <div className="mt-2">
                  <a
                    href={directionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-[var(--foreground)] hover:underline"
                  >
                    Get Directions
                  </a>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

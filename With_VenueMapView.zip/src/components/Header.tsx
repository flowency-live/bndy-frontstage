"use client";

import { usePathname } from "next/navigation";
import BndyLogo from "@/components/ui/bndylogo";
import { Sun, Moon, Map as MapIcon, List as ListIcon, Building2, Music } from "lucide-react";
import { useViewToggle } from "@/context/ViewToggleContext";
import { useOverlayMode } from "@/context/OverlayModeContext";

export default function Header() {
  const pathname = usePathname();
  const { activeView, setActiveView, isDarkMode, toggleTheme } = useViewToggle();

  // Only show the map/list toggle if we are on the home page ("/")
  const showViewToggle = pathname === "/";

  const handleViewToggle = () => {
    setActiveView((prev) => (prev === "map" ? "list" : "map"));
  };

  // Overlay mode toggle and showAllVenues state from context
  const { overlayMode, setOverlayMode, showAllVenues, setShowAllVenues } = useOverlayMode();
  const handleOverlayToggle = () => {
    setOverlayMode(overlayMode === "venues" ? "events" : "venues");
  };

  return (
    <header
      className="fixed top-3 left-0 right-0 z-50"
      style={{ backgroundColor: "var(--background)" }}
    >
      {/* Use a container with horizontal padding so that content aligns */}
      <div className="relative container mx-auto px-4">
        {/* Top-right corner toggles: Theme & Map/List */}
        <div className="absolute top-0 right-0 mt-2 mr-2 flex items-center space-x-4">
          <button
            onClick={toggleTheme}
            className="flex items-center focus:outline-none"
            title={isDarkMode ? "Switch to light mode" : "Switch to dark mode"}
          >
            {isDarkMode ? (
              <Sun className="w-5 h-5 text-[var(--foreground)]" />
            ) : (
              <Moon className="w-5 h-5 text-[var(--foreground)]" />
            )}
          </button>
          {showViewToggle && (
            <button onClick={handleViewToggle} className="flex items-center focus:outline-none">
              {activeView === "map" ? (
                <ListIcon className="w-5 h-5 text-[var(--foreground)]" />
              ) : (
                <MapIcon className="w-5 h-5 text-[var(--foreground)]" />
              )}
            </button>
          )}
        </div>

        {/* Centered logo and tagline */}
        <div className="text-center">
          <div className="flex justify-center">
            <BndyLogo />
          </div>
          <div className="hidden sm:block text-base leading-snug mt-1">
            Keeping{" "}
            <span className="font-extrabold text-[var(--secondary)]">LIVE</span> music{" "}
            <span className="font-extrabold text-[var(--primary)]">ALIVE</span>
          </div>
          <div className="block sm:hidden text-base leading-snug mt-1">
            Keeping{" "}
            <span className="font-extrabold text-[var(--secondary)]">LIVE</span>
            <br />
            music{" "}
            <span className="font-extrabold text-[var(--primary)]">ALIVE</span>
          </div>
        </div>

        {/* Bottom-left VET container - only on home page and when in map view */}
        {pathname === "/" && activeView === "map" && (
          <div className="absolute bottom-0 left-0 m-2 flex flex-col items-start space-y-2">
            <button
              onClick={handleOverlayToggle}
              className={`flex items-center gap-1 px-3 py-1 rounded-md focus:outline-none ${
                overlayMode === "events"
                  ? "bg-[var(--secondary)] text-white"
                  : "bg-orange-500 text-white"
              }`}
            >
              {overlayMode === "events" ? (
                <>
                  <Building2 className="w-4 h-4" />
                  <span className="text-sm">Venues</span>
                </>
              ) : (
                <>
                  <Music className="w-4 h-4" />
                  <span className="text-sm">Events</span>
                </>
              )}
            </button>
            {overlayMode === "venues" && (
              <label className="flex items-center space-x-1 text-xs sm:text-sm text-[var(--foreground)]">
                <input
                  type="checkbox"
                  checked={showAllVenues}
                  onChange={(e) => setShowAllVenues(e.target.checked)}
                  className="w-4 h-4"
                />
                <span>All Venues</span>
              </label>
            )}
          </div>
        )}
      </div>
    </header>
  );
}

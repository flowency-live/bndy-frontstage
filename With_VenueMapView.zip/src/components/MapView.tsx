"use client";

import { Wrapper, Status } from "@googlemaps/react-wrapper";
import { useOverlayMode } from "@/context/OverlayModeContext";
import { useState, useRef, useCallback } from "react";
import EventFilter from "./filters/EventFilter";
import { MapViewEventsFilter } from "./filters/MapViewEventsFilter";
import { AddEventButton } from "./events/AddEventButton";
import Map from "./map/Map"; // your existing event map component
import VenueMapView from "./VenueMapView"; // venue map view component

const renderStatus = (status: Status): React.ReactElement => {
  switch (status) {
    case Status.LOADING:
      return <div className="flex items-center justify-center h-full">Loading map...</div>;
    case Status.FAILURE:
      return <div className="flex items-center justify-center h-full text-red-500">Error loading Google Maps</div>;
    default:
      return <></>;
  }
};

export default function MapView() {
  const [filterType, setFilterType] = useState<'artist' | 'venue' | 'nomatch' | null>(null);
  const [filterId, setFilterId] = useState<string | null>(null);
  const mapRef = useRef<google.maps.Map | null>(null);
  
  // Use refs to store the current center and zoom without triggering re-renders.
  const currentCenterRef = useRef<google.maps.LatLngLiteral | null>(null);
  const currentZoomRef = useRef<number>(12);

  // Use a stable callback for filter changes.
  const handleFilterChange = useCallback(
    (type: 'artist' | 'venue' | 'nomatch' | null, text: string | null) => {
      setFilterType(type);
      setFilterId(text);
    },
    []
  );

  const handleMapLoad = (map: google.maps.Map) => {
    mapRef.current = map;
    const center = map.getCenter();
    if (center) {
      currentCenterRef.current = center.toJSON();
    }
    currentZoomRef.current = map.getZoom() ?? 12;

    // Attach an "idle" listener to update our refs when the map stops moving.
    map.addListener("idle", () => {
      const newCenterObj = map.getCenter();
      if (newCenterObj) {
        currentCenterRef.current = newCenterObj.toJSON();
      }
      currentZoomRef.current = map.getZoom() ?? 12;
    });
  };

  const { overlayMode } = useOverlayMode();

  return (
    <div className="map-container relative">
      {/* Search filter above the map */}
      <div className="absolute top-0 left-0 right-0 z-10 px-4 py-2">
        <EventFilter onFilterChange={handleFilterChange} showRadiusFilter={false} />
      </div>

      <Wrapper
        apiKey={process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || ""}
        render={renderStatus}
        libraries={["places"]}
      >
        {overlayMode === "events" ? (
          <Map 
            filterType={filterType} 
            filterId={filterId} 
            onMapLoaded={handleMapLoad} 
            initialCenter={currentCenterRef.current || undefined} 
            initialZoom={currentZoomRef.current}
          />
        ) : (
          <VenueMapView 
            filterType={filterType} 
            filterId={filterId} 
            onMapLoaded={handleMapLoad} 
            initialCenter={currentCenterRef.current || undefined} 
            initialZoom={currentZoomRef.current}
          />
        )}
      </Wrapper>

      {/* Quick filter button in the bottom left */}
      <MapViewEventsFilter />

      {/* Add Event button in the bottom right */}
      <AddEventButton map={mapRef.current} />
    </div>
  );
}

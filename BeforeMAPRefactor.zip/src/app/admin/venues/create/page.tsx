// /app/admin/venues/create/page.tsx
"use client";

import { VenueEdit } from "@/components/admin/edit/VenueEdit";

export default function CreateVenuePage() {
  return <VenueEdit />;
}
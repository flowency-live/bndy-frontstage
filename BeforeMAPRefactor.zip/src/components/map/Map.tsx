// src/components/Map/Map.tsx
"use client";


import { useEffect, useState, useRef } from "react";
import { useViewToggle } from "@/context/ViewToggleContext";
import { useEvents } from "@/context/EventsContext";
import { DEFAULT_CENTER } from "./sampleData";
import L from "leaflet";
import 'leaflet.markercluster';
import "leaflet/dist/leaflet.css";
import "leaflet.markercluster/dist/MarkerCluster.css";
import "leaflet.markercluster/dist/MarkerCluster.Default.css";
import { Event, Venue } from "@/lib/types";
import { formatEventDate, formatTime } from "@/lib/utils/date-utils";
import EventInfoOverlay from "../overlays/EventInfoOverlay";
import VenueInfoOverlay from "../overlays/VenueInfoOverlay";
import { getAllVenuesForMap } from "@/lib/services/venue-service";
import { isDateInRange, DateRangeFilter } from '@/lib/utils/date-filter-utils';

// Fix for the Leaflet default icon issue in Next.js
import { completeLeafletIconFix } from "./leaflet-icon-fix";
// Import marker utilities
import { createEventMarkerIcon, createVenueMarkerIcon, createUserLocationMarkerIcon, createEventClusterIcon } from "./LeafletMarkers";

// Configure the tile layers for light and dark modes
export const lightTileLayer = {
  url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
  // url: "https://api.maptiler.com/maps/d8bcba2a-751e-42cd-8b48-eaa1249c85e1/{z}/{x}/{y}.png?key=Qk4IcpqNjakg46JvdEuP",
  attribution: ''
  //'&copy;  <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
};

// export const darkTileLayer = {
//   url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
//   //url: "https://api.maptiler.com/maps/7d023cd5-2744-4757-9080-a90cd695aacc/{z}/{x}/{y}.png?key=Qk4IcpqNjakg46JvdEuP",
//   attribution: ''
//   //'&copy;  <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
// };

export const darkTileLayer = {
  url: "https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png",
  attribution: '&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>, &copy; <a href="https://openmaptiles.org/">OpenMapTiles</a> &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors'
};

type FilterType = "artist" | "venue" | "nomatch" | null;

interface MapProps {
  filterType?: FilterType;
  filterId?: string | null;
}

// Create custom venue cluster icon
const createVenueClusterIcon = (cluster: L.MarkerCluster) => {
  const count = cluster.getChildCount();

  // Get color based on cluster size
  const getVenueClusterColor = (count: number) => {
    if (count < 10) return "#FF1493"; // Pink for small clusters
    if (count < 50) return "#E0115F"; // Deeper pink for medium clusters
    return "#C71585"; // Magenta for large clusters
  };

  // Create cluster HTML
  const html = `
  <div style="
    background-color: ${getVenueClusterColor(count)};
    color: white;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: bold;
    font-size: 14px;
    border: 2px solid white;
    box-shadow: 0 1px 4px rgba(0,0,0,0.3);
  ">${count}</div>
`;

  return L.divIcon({
    html: html,
    className: 'leaflet-cluster-icon',
    iconSize: L.point(40, 40)
  });
};



const Map = ({ filterType, filterId }: MapProps) => {
  const { isDarkMode, mapMode } = useViewToggle();
  const {
    userLocation,
    allEvents,
    events,
    loading: eventsLoading,
    dateRange
  } = useEvents();

  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const eventMarkersRef = useRef<Record<string, L.Marker>>({});
  const venueMarkersRef = useRef<Record<string, L.Marker>>({});
  const venueClusterRef = useRef<L.MarkerClusterGroup | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [selectedEvents, setSelectedEvents] = useState<Event[]>([]);
  const [selectedVenue, setSelectedVenue] = useState<Venue | null>(null);
  const [showEventOverlay, setShowEventOverlay] = useState(false);
  const [showVenueOverlay, setShowVenueOverlay] = useState(false);

  // State for venues - fetch ALL venues separately
  const [venues, setVenues] = useState<Venue[]>([]);
  const [venuesLoading, setVenuesLoading] = useState(false);
  const [filteredEvents, setFilteredEvents] = useState<Event[]>([]);
  const [venueToEventMap, setVenueToEventMap] = useState<Record<string, Event[]>>({});

  // Initialize and cleanup the map
  useEffect(() => {
    // Fix Leaflet's default icon paths
    completeLeafletIconFix();

    // Check if we already have a map instance
    if (mapInstanceRef.current) {
      return; // Map already initialized
    }

    // Make sure the container exists
    if (!mapContainerRef.current) {
      return;
    }

    // Set initial center based on user location or default
    const center = userLocation
      ? [userLocation.lat, userLocation.lng]
      : [DEFAULT_CENTER.lat, DEFAULT_CENTER.lng];

    // Create the map instance
    const map = L.map(mapContainerRef.current, {
      center: center as [number, number],
      zoom: 12,
      zoomControl: false,
      attributionControl: true,
      closePopupOnClick: true // Ensure popups close when clicking elsewhere
    });

    // Add a custom location button
    const locationButton = new L.Control({ position: 'bottomright' });
    locationButton.onAdd = () => {
      const div = L.DomUtil.create('div', 'leaflet-bar leaflet-control');
      div.innerHTML = `
    <a href="#" title="Center on my location" role="button" aria-label="Center on my location" class="leaflet-control-locate">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4">
        <circle cx="12" cy="12" r="10"></circle>
        <circle cx="12" cy="12" r="3"></circle>
      </svg>
    </a>
  `;
      div.style.cssText = 'background-color: white; cursor: pointer;';
      div.onclick = (e) => {
        e.preventDefault();
        if (userLocation) {
          map.setView([userLocation.lat, userLocation.lng], 14);
        }
      };
      return div;
    };
    locationButton.addTo(map);

    // Add tile layer based on theme
    const tileLayer = isDarkMode ? darkTileLayer : lightTileLayer;
    L.tileLayer(tileLayer.url, {
      attribution: tileLayer.attribution,
      maxZoom: 19,
    }).addTo(map);

    // Save the map instance
    mapInstanceRef.current = map;

    // Close overlays when clicking on the map
    map.on('click', () => {
      setShowEventOverlay(false);
      setSelectedEvents([]);
      setSelectedEvent(null);
      setShowVenueOverlay(false);
      setSelectedVenue(null);
    });

    // Cleanup function to remove the map when component unmounts
    return () => {
      if (mapInstanceRef.current) {
        clearAllMarkers();
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Handle user location marker
  useEffect(() => {
    if (!mapInstanceRef.current) return;

    // Remove existing user marker
    if (userMarkerRef.current) {
      userMarkerRef.current.remove();
      userMarkerRef.current = null;
    }

    // Add the user location marker if available
    if (userLocation) {
      const userMarker = L.marker([userLocation.lat, userLocation.lng], {
        icon: createUserLocationMarkerIcon(),
        zIndexOffset: 1000 // Ensure user marker is on top
      });

      userMarker.addTo(mapInstanceRef.current);
      userMarkerRef.current = userMarker;



      // Optionally center on user location if it's the first load
      if (userLocation && !mapInstanceRef.current.getBounds().contains(userLocation)) {
        mapInstanceRef.current.setView([userLocation.lat, userLocation.lng], 12);
      }
    }
  }, [userLocation]);

  // Generate venueToEvent map
  useEffect(() => {
    if (!allEvents || !allEvents.length) return;

    const map: Record<string, Event[]> = {};

    // Group events by venue location (lat+lng as key)
    allEvents.forEach(event => {
      if (!event.location) return;

      const key = `${event.location.lat},${event.location.lng}`;
      if (!map[key]) {
        map[key] = [];
      }
      map[key].push(event);
    });

    setVenueToEventMap(map);
  }, [allEvents]);

  // Apply date range and search filters to events
  useEffect(() => {
    if (!allEvents || allEvents.length === 0) return;

    // First apply date filter
    let dateFiltered = allEvents;
    if (dateRange) {
      dateFiltered = allEvents.filter(event => {
        const eventDate = new Date(event.date);
        return isDateInRange(eventDate, dateRange as DateRangeFilter);
      });
    }

    // Then apply search filter if needed
    let searchFiltered = dateFiltered;
    if (filterType && filterId && filterId.trim() !== '') {
      if (filterType === 'nomatch') {
        searchFiltered = []; // No results
      } else {
        const searchTerm = filterId.toLowerCase();

        if (filterType === 'artist') {
          searchFiltered = dateFiltered.filter(event =>
            event.name.toLowerCase().includes(searchTerm)
          );
        } else if (filterType === 'venue') {
          searchFiltered = dateFiltered.filter(event =>
            event.venueName.toLowerCase().includes(searchTerm)
          );
        }
      }
    }

    // Important: Now deduplicate events by location to avoid clustering
    const locationKeyMap: Record<string, Event> = {};
    searchFiltered.forEach(event => {
      if (!event.location) return;

      const locationKey = `${event.location.lat},${event.location.lng}`;

      // If this location already has an event, don't add another marker
      // (we'll handle multiple events at the same location with our custom overlay)
      if (!locationKeyMap[locationKey]) {
        locationKeyMap[locationKey] = event;
      }
    });

    // Convert map back to array, but with only one event per location
    const deduplicatedEvents = Object.values(locationKeyMap);

    setFilteredEvents(deduplicatedEvents);
  }, [allEvents, dateRange, filterType, filterId]);

  // Load ALL venues when in venue mode
  useEffect(() => {
    if (mapMode === 'venues' && venues.length === 0 && !venuesLoading) {
      const fetchVenues = async () => {
        setVenuesLoading(true);
        try {
          const venueData = await getAllVenuesForMap();
          setVenues(venueData);
        } catch (error) {
          console.error("Error fetching venues:", error);
        } finally {
          setVenuesLoading(false);
        }
      };

      fetchVenues();
    }
  }, [mapMode, venues.length, venuesLoading]);

  // Update the tile layer when theme changes
  useEffect(() => {
    if (!mapInstanceRef.current) return;

    // Remove existing tile layers
    mapInstanceRef.current.eachLayer(layer => {
      if (layer instanceof L.TileLayer) {
        mapInstanceRef.current?.removeLayer(layer);
      }
    });

    // Add new tile layer based on theme
    const tileLayer = isDarkMode ? darkTileLayer : lightTileLayer;
    L.tileLayer(tileLayer.url, {
      attribution: tileLayer.attribution,
      maxZoom: 19,
    }).addTo(mapInstanceRef.current);
  }, [isDarkMode]);

  // Clear all markers
  const clearAllMarkers = () => {
    if (!mapInstanceRef.current) return;

    // Remove venue cluster group if it exists
    if (venueClusterRef.current) {
      mapInstanceRef.current.removeLayer(venueClusterRef.current);
      venueClusterRef.current = null;
    }

    // Clear existing markers
    Object.values(eventMarkersRef.current).forEach(marker => {
      marker.remove();
    });

    Object.values(venueMarkersRef.current).forEach(marker => {
      marker.remove();
    });

    // Reset marker refs
    eventMarkersRef.current = {};
    venueMarkersRef.current = {};
  };

  // Handle adding event markers based on map mode
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    if (mapMode === 'events' && eventsLoading) return;
    if (mapMode === 'venues' && venuesLoading) return;

    // Make sure we clear ALL markers first
    clearAllMarkers();

    if (mapMode === 'events') {
      addEventMarkers();
    } else {
      addVenueMarkers();
    }
  }, [mapMode, filteredEvents, venues, eventsLoading, venuesLoading, isDarkMode]);

  // Add event markers to the map (NO clustering for events)
  const addEventMarkers = () => {
    if (!mapInstanceRef.current || filteredEvents.length === 0) return;

    // Create a cluster group for events
    const clusterGroup = L.markerClusterGroup({
      maxClusterRadius: 60,
      iconCreateFunction: createEventClusterIcon,
      zoomToBoundsOnClick: true,
      showCoverageOnHover: false,
      spiderfyOnMaxZoom: true,
      disableClusteringAtZoom: 16
    });

    // Group events by exact location to prevent duplicates at the same spot
    const locationGroups: Record<string, Event[]> = {};

    // First group events by exact location coordinates
    filteredEvents.forEach(event => {
      if (!event.location || !event.location.lat || !event.location.lng) return;

      const locationKey = `${event.location.lat},${event.location.lng}`;

      if (!locationGroups[locationKey]) {
        locationGroups[locationKey] = [];
      }

      locationGroups[locationKey].push(event);
    });

    // Now create a single marker for each location
    Object.entries(locationGroups).forEach(([locationKey, events]) => {
      if (!events.length) return;

      // Use the first event for the marker position
      const event = events[0];

      // Create marker with event icon
      const marker = L.marker([event.location!.lat, event.location!.lng], {
        icon: createEventMarkerIcon()
      });

      // Add click handler for detailed info
      marker.on('click', (e) => {
        // Stop propagation to prevent default behavior
        L.DomEvent.stopPropagation(e);

        // Center map on marker
        mapInstanceRef.current?.panTo([event.location!.lat, event.location!.lng]);

        // Set all events at this location to the overlay
        setSelectedEvents(events);
        setShowEventOverlay(true);

        // Close venue overlay if open
        setShowVenueOverlay(false);
        setSelectedVenue(null);
      });

      // Add to cluster group
      clusterGroup.addLayer(marker);

      // Store marker reference for cleanup
      eventMarkersRef.current[locationKey] = marker;
    });

    // Add the cluster group to the map
    mapInstanceRef.current.addLayer(clusterGroup);
  };

  // Add venue markers to the map (WITH clustering)
  const addVenueMarkers = () => {
    if (!mapInstanceRef.current || !venues.length) return;

    // Create a cluster group for venues
    const clusterGroup = L.markerClusterGroup({
      maxClusterRadius: 60,
      iconCreateFunction: createVenueClusterIcon,
      zoomToBoundsOnClick: true,
      showCoverageOnHover: false,
      spiderfyOnMaxZoom: true,
      disableClusteringAtZoom: 16
    });

    // First, create a map of venue IDs to associated events
    const venueEvents: Record<string, Event[]> = {};

    // Initialize with empty arrays for all venues
    venues.forEach(venue => {
      venueEvents[venue.id] = [];
    });

    // Add events to their respective venues
    if (allEvents && allEvents.length) {
      allEvents.forEach(event => {
        if (event.venueId && venueEvents[event.venueId]) {
          venueEvents[event.venueId].push(event);
        }
      });
    }

    // Now create markers for all venues
    venues.forEach(venue => {
      if (!venue.location || !venue.location.lat || !venue.location.lng) return;

      // Get count of events for this venue (might be 0)
      const eventCount = venueEvents[venue.id] ? venueEvents[venue.id].length : 0;

      // Create marker with venue icon
      const marker = L.marker(
        [venue.location.lat, venue.location.lng],
        {
          icon: createVenueMarkerIcon(eventCount),
          interactive: true,
          title: venue.name
        }
      );

      // Disable the popup entirely - we'll use our custom overlay only

      // Add click handler for venue
      marker.on('click', (e) => {
        // Prevent default behavior
        L.DomEvent.stopPropagation(e);

        // Center map on marker
        mapInstanceRef.current?.panTo([venue.location!.lat, venue.location!.lng]);

        // When venue is clicked, show venue overlay
        setSelectedVenue(venue);
        setShowVenueOverlay(true);

        // Close event overlay if open
        setShowEventOverlay(false);
        setSelectedEvents([]);
        setSelectedEvent(null);
      });

      // Add to cluster group and track for cleanup
      clusterGroup.addLayer(marker);
      venueMarkersRef.current[venue.id] = marker;
    });

    // Add the cluster group to the map
    mapInstanceRef.current.addLayer(clusterGroup);
    venueClusterRef.current = clusterGroup;
  };

  return (
    <div className="w-full h-full relative">
      <div
        ref={mapContainerRef}
        className="w-full h-full"
        style={{ zIndex: 10 }}  // Ensure map is behind UI elements
      />

      {/* Loading indicators */}
      {(eventsLoading && mapMode === 'events') && (
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black bg-opacity-70 text-white p-4 rounded z-20">
          Loading events...
        </div>
      )}

      {(venuesLoading && mapMode === 'venues') && (
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black bg-opacity-70 text-white p-4 rounded z-20">
          Loading venues...
        </div>
      )}

      {/* No matches indicator */}
      {filterType === 'nomatch' && filterId && (
        <div className="absolute top-12 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-70 text-white p-2 rounded text-sm z-20">
          No matches found for "{filterId}"
        </div>
      )}

      {/* Show message when no events match filters */}
      {mapMode === 'events' && !eventsLoading && filteredEvents.length === 0 && (
        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-70 text-white p-2 rounded text-sm z-20">
          No events match the current filters
        </div>
      )}

      {/* Event Info Overlay */}
      {selectedEvents.length > 0 && (
        <EventInfoOverlay
          events={selectedEvents}
          isOpen={showEventOverlay}
          onClose={() => {
            setShowEventOverlay(false);
            setSelectedEvents([]);
            setSelectedEvent(null);
          }}
          position="map"
        />
      )}

      {/* Venue Info Overlay */}
      {selectedVenue && (
        <VenueInfoOverlay
          venue={selectedVenue}
          isOpen={showVenueOverlay}
          onClose={() => {
            setShowVenueOverlay(false);
            setSelectedVenue(null);
          }}
          position="map"
        />
      )}
    </div>
  );
};

export default Map;
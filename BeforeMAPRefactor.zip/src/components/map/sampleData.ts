// src/components/Map/sampleData.ts
export const DEFAULT_CENTER = { lat: 51.505, lng: -0.09 };

// src/components/Map/LeafletConfig.ts
"use client";


import L from "leaflet";

if (typeof window !== "undefined") {
  // Use require() so these assets are only loaded on the client.
  const markerIcon2x = require("leaflet/dist/images/marker-icon-2x.png");
  const markerIcon = require("leaflet/dist/images/marker-icon.png");
  const markerShadow = require("leaflet/dist/images/marker-shadow.png");

  // Delete the property with a type assertion to bypass TS error.
  delete (L.Icon.Default.prototype as any)._getIconUrl;

  L.Icon.Default.mergeOptions({
    iconRetinaUrl: markerIcon2x,
    iconUrl: markerIcon,
    shadowUrl: markerShadow,
  });
}
